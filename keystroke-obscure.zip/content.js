// Create overlay
const overlay = document.createElement('div');
overlay.className = 'private-input-overlay';
const input = document.createElement('input');
input.type = 'text';
input.className = 'private-input-box';
overlay.appendChild(input);
document.body.appendChild(overlay);

let activeElement = null;
let isOverlayActive = false;
let preventFocusIn = false;

// Function to position overlay over input
function positionOverlay(element) {
  const rect = element.getBoundingClientRect();
  const scrollX = window.scrollX || window.pageXOffset;
  const scrollY = window.scrollY || window.pageYOffset;

  overlay.style.position = 'absolute';
  overlay.style.top = `${rect.top + scrollY}px`;
  overlay.style.left = `${rect.left + scrollX}px`;
  
  overlay.style.width = `${rect.width}px`;
  input.style.width = '100%';
  input.style.height = `${rect.height}px`;
  
  const styles = window.getComputedStyle(element);
  input.style.fontSize = styles.fontSize;
  input.style.padding = styles.padding;
  input.style.fontFamily = styles.fontFamily;
  input.style.borderRadius = styles.borderRadius;
}

function showOverlay(element) {
  activeElement = element;
  isOverlayActive = true;
  overlay.style.display = 'block';
  input.value = element.value || '';
  
  positionOverlay(element);
  
  setTimeout(() => {
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  }, 0);
}

// Global keystroke protection
document.addEventListener('keydown', function(e) {
  const target = e.target;
  
  // Allow keystrokes if:
  // 1. User is typing in our overlay
  // 2. User is typing in a legitimate input field
  // 3. User is using keyboard shortcuts (e.g., Ctrl+R for refresh)
  if (overlay.contains(target) || 
      e.ctrlKey || e.metaKey || e.altKey ||
      target.tagName === 'INPUT' ||
      target.tagName === 'TEXTAREA' ||
      target.isContentEditable) {
    return; // Allow the keystroke
  }
  
  // Block the keystroke from being seen by the page
  e.stopImmediatePropagation();
  e.preventDefault();
}, true); // Use capture phase to intercept before other listeners

// Handle focus on any input element
document.addEventListener('focusin', (e) => {
  if (preventFocusIn) {
    preventFocusIn = false;
    return;
  }

  if (!isOverlayActive && 
      (e.target.tagName === 'INPUT' || 
       e.target.tagName === 'TEXTAREA' || 
       e.target.isContentEditable)) {
    showOverlay(e.target);
  }
});

// Handle input submission
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && activeElement) {
    e.preventDefault();
    
    activeElement.value = input.value;
    
    const event = new Event('input', { bubbles: true });
    activeElement.dispatchEvent(event);
    
    overlay.style.display = 'none';
    input.value = '';
    isOverlayActive = false;
    
    preventFocusIn = true;
    activeElement.focus();
  }
  
  if (e.key === 'Escape') {
    overlay.style.display = 'none';
    input.value = '';
    isOverlayActive = false;
    preventFocusIn = true;
    if (activeElement) activeElement.focus();
  }
});

// Modified click handler to handle reopening
document.addEventListener('mousedown', (e) => {
  if (!overlay.contains(e.target)) {
    if (e.target === activeElement && !isOverlayActive) {
      e.preventDefault();
      showOverlay(e.target);
    } else if (e.target !== activeElement) {
      overlay.style.display = 'none';
      input.value = '';
      isOverlayActive = false;
    }
  }
});

// Handle window resize
window.addEventListener('resize', () => {
  if (isOverlayActive && activeElement) {
    positionOverlay(activeElement);
  }
});

// Handle scroll events
document.addEventListener('scroll', (e) => {
  if (isOverlayActive && activeElement) {
    positionOverlay(activeElement);
  }
}, true);
