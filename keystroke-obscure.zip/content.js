// Create overlay
const overlay = document.createElement('div');
overlay.className = 'private-input-overlay';
const input = document.createElement('input');
input.type = 'text';
input.className = 'private-input-box';
overlay.appendChild(input);
document.body.appendChild(overlay);

let activeElement = null;
let isOverlayActive = false;
let preventFocusIn = false;

// Function to position overlay over input
function positionOverlay(element) {
  const rect = element.getBoundingClientRect();
  const scrollX = window.scrollX || window.pageXOffset;
  const scrollY = window.scrollY || window.pageYOffset;

  overlay.style.position = 'absolute';
  overlay.style.top = `${rect.top + scrollY}px`;
  overlay.style.left = `${rect.left + scrollX}px`;
  
  overlay.style.width = `${rect.width}px`;
  input.style.width = '100%';
  input.style.height = `${rect.height}px`;
  
  const styles = window.getComputedStyle(element);
  input.style.fontSize = styles.fontSize;
  input.style.padding = styles.padding;
  input.style.fontFamily = styles.fontFamily;
  input.style.borderRadius = styles.borderRadius;
}

function showOverlay(element) {
  activeElement = element;
  isOverlayActive = true;
  overlay.style.display = 'block';
  input.value = element.value || '';
  
  positionOverlay(element);
  
  setTimeout(() => {
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  }, 0);
}

function submitAndClose() {
  if (activeElement) {
    activeElement.value = input.value;
    const event = new Event('input', { bubbles: true });
    activeElement.dispatchEvent(event);
  }
  
  overlay.style.display = 'none';
  input.value = '';
  isOverlayActive = false;
}

// Global keystroke protection
document.addEventListener('keydown', function(e) {
  const target = e.target;
  
  // Allow keystrokes if:
  if (overlay.contains(target) || 
      e.ctrlKey || e.metaKey || e.altKey ||
      target.tagName === 'INPUT' ||
      target.tagName === 'TEXTAREA' ||
      target.isContentEditable) {
    return;
  }
  
  e.stopImmediatePropagation();
  e.preventDefault();
}, true);

// Handle focus on any input element
document.addEventListener('focusin', (e) => {
  if (preventFocusIn) {
    preventFocusIn = false;
    return;
  }

  if (!isOverlayActive && 
      (e.target.tagName === 'INPUT' || 
       e.target.tagName === 'TEXTAREA' || 
       e.target.isContentEditable)) {
    showOverlay(e.target);
  }
});

// Handle input keydown events
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && activeElement) {
    e.preventDefault();
    submitAndClose();
    preventFocusIn = true;
    activeElement.focus();
  }
  else if (e.key === 'Escape') {
    overlay.style.display = 'none';
    input.value = '';
    isOverlayActive = false;
    preventFocusIn = true;
    if (activeElement) activeElement.focus();
  }
  else if (e.key === 'Tab') {
    e.preventDefault();
    submitAndClose();
    
    // Find the next focusable element
    const focusable = Array.from(document.querySelectorAll('input, textarea, [contenteditable="true"]'));
    const currentIndex = focusable.indexOf(activeElement);
    const nextElement = e.shiftKey ? 
      focusable[currentIndex - 1] || focusable[focusable.length - 1] : 
      focusable[currentIndex + 1] || focusable[0];
    
    // Focus the next element and show overlay
    if (nextElement) {
      nextElement.focus();
      showOverlay(nextElement);
    }
  }
});

// Modified click handler to handle reopening
document.addEventListener('mousedown', (e) => {
  if (!overlay.contains(e.target)) {
    if (e.target === activeElement && !isOverlayActive) {
      e.preventDefault();
      showOverlay(e.target);
    } else if (e.target !== activeElement) {
      overlay.style.display = 'none';
      input.value = '';
      isOverlayActive = false;
    }
  }
});

// Handle window resize
window.addEventListener('resize', () => {
  if (isOverlayActive && activeElement) {
    positionOverlay(activeElement);
  }
});

// Handle scroll events
document.addEventListener('scroll', (e) => {
  if (isOverlayActive && activeElement) {
    positionOverlay(activeElement);
  }
}, true);
